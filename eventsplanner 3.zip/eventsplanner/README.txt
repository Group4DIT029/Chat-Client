A Pen created at CodePen.io. You can find this one at http://codepen.io/maggiben/pen/KwdeaM.

 A fork from http://codepen.io/magnus16/pen/emNbav with added javascript to sync video playback